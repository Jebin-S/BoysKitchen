// Firebase config (replace with your own)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  databaseURL: "YOUR_DB_URL",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_BUCKET",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// Tab switching
function openTab(evt, tabName) {
  document.querySelectorAll('.tabcontent').forEach(t => t.classList.remove('active'));
  document.getElementById(tabName).classList.add('active');
}

// Menu Form
const menuForm = document.getElementById('menuForm');
menuForm.addEventListener('submit', e => {
  e.preventDefault();
  const id = document.getElementById('menuItemId').value;
  let imagePath = '';
  const fileInput = document.getElementById('menuImageFile');
  if (fileInput.files.length > 0) {
    const fileName = fileInput.files[0].name;
    imagePath = '/images/' + fileName; // served by Netlify
  }
  const data = {
    name: document.getElementById('menuName').value,
    price: parseInt(document.getElementById('menuPrice').value),
    category: document.getElementById('menuCategory').value,
    stock: parseInt(document.getElementById('menuStock').value),
    image: imagePath
  };
  if (id) {
    db.ref('menu/' + id).set(data);
  } else {
    db.ref('menu').push(data);
  }
  menuForm.reset();
});

// Render Menu
db.ref('menu').on('value', snap => {
  const data = snap.val() || {};
  const menuList = document.getElementById('menuList');
  const menuMgmtList = document.getElementById('menuMgmtList');
  menuList.innerHTML = '';
  menuMgmtList.innerHTML = '';
  Object.entries(data).forEach(([id, item]) => {
    // Fallback placeholder image
    const imgSrc = item.image && item.image.trim() !== '' ? item.image : '/images/no-image.png';

    // For orders
    const div = document.createElement('div');
    div.className = 'menu-item';
    div.innerHTML = `
      <img src="${imgSrc}" alt="${item.name}">
      <div class="menu-info">
        <h4>${item.name}</h4>
        <p>₹${item.price}</p>
        <input type="number" min="0" value="0" class="menu-qty" 
          data-id="${id}" data-name="${item.name}" data-price="${item.price}">
      </div>`;
    menuList.appendChild(div);

    // For management
    const li = document.createElement('li');
    li.textContent = `${item.name} - ₹${item.price} - ${item.category}`;
    menuMgmtList.appendChild(li);
  });
});

// Order Form
const orderForm = document.getElementById('orderForm');
orderForm.addEventListener('input', e => {
  let total = 0;
  orderForm.querySelectorAll('input[type=number][data-price]').forEach(inp => {
    total += parseInt(inp.value) * parseInt(inp.dataset.price);
  });
  document.getElementById('orderTotal').textContent = total;
});

orderForm.addEventListener('submit', e => {
  e.preventDefault();
  const customer = document.getElementById('customerName').value;
  const items = [];
  let total = 0;
  orderForm.querySelectorAll('input[type=number][data-price]').forEach(inp => {
    if (parseInt(inp.value) > 0) {
      items.push({
        id: inp.dataset.id,
        name: inp.dataset.name,
        price: parseInt(inp.dataset.price),
        quantity: parseInt(inp.value)
      });
      total += parseInt(inp.value) * parseInt(inp.dataset.price);
    }
  });
  db.ref('orders').push({
    customer, items, total, status: 'pending', timestamp: Date.now()
  });
  orderForm.reset();
  document.getElementById('orderTotal').textContent = 0;
});

// Kitchen and Delivery
db.ref('orders').on('value', snap => {
  const data = snap.val() || {};
  const kitchenList = document.getElementById('kitchenList');
  const deliveryList = document.getElementById('deliveryList');
  const allOrdersList = document.getElementById('allOrdersList');
  kitchenList.innerHTML = '';
  deliveryList.innerHTML = '';
  allOrdersList.innerHTML = '';
  const totals = {};
  Object.entries(data).forEach(([id, order]) => {
    order.items.forEach(it => {
      totals[it.name] = (totals[it.name] || 0) + it.quantity;
    });
    if (order.status === 'pending') {
      const li = document.createElement('li');
      li.innerHTML = `${order.customer} - ₹${order.total} 
        <button onclick="markDelivered('${id}')">Delivered</button>`;
      deliveryList.appendChild(li);
    }
    const li2 = document.createElement('li');
    li2.textContent = `${order.customer} - ₹${order.total} (${order.status})`;
    allOrdersList.appendChild(li2);
  });
  Object.entries(totals).forEach(([name, qty]) => {
    const li = document.createElement('li');
    li.textContent = `${name}: ${qty}`;
    kitchenList.appendChild(li);
  });
});

function markDelivered(id) {
  db.ref('orders/' + id + '/status').set('delivered');
}
